<?php
session_start();
include 'db_connect.php';

$category = isset($_GET['category']) ? $_GET['category'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

$sql = "SELECT * FROM sanpham WHERE 1";
if ($category) {
    $sql .= " AND category = '" . $conn->real_escape_string($category) . "'";
}
if ($search) {
    $sql .= " AND name LIKE '%" . $conn->real_escape_string($search) . "%'";
}
$result = $conn->query($sql);
$conn->close();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách sản phẩm</title>
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    <h2>Danh sách sản phẩm</h2>
    <a href="index.php">Trang chủ</a>
    
    <form method="GET" action="">
        <input type="text" name="search" placeholder="Tìm kiếm sản phẩm..." value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit">Tìm</button>
    </form>
    
    <div class="product-grid">
        <?php if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) { ?>
                <div class='product-card'>
                    <img src='<?php echo htmlspecialchars($row['image']); ?>' alt='<?php echo htmlspecialchars($row['name']); ?>'>
                    <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                    <p>Giá: <?php echo number_format($row['price']); ?> VND</p>
                    <a href='product_detail.php?id=<?php echo $row['id']; ?>'>Xem chi tiết</a>
                    <button class="add-to-cart" data-id="<?php echo $row['id']; ?>">Thêm vào giỏ hàng</button>
                </div>
            <?php }
        } else {
            echo "<p>Không tìm thấy sản phẩm nào.</p>";
        } ?>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            $(".add-to-cart").click(function () {
                let productId = $(this).data("id");
                $.post("cart.php", { action: "add", product_id: productId }, function (response) {
                    alert(response);
                });
            });
        });
    </script>
</body>
</html>

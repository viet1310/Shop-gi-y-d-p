<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'db_connect.php';

$user_id = $_SESSION['user_id'];
$sql = "SELECT fullname, email, role FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang cá nhân</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Xin chào, <?php echo htmlspecialchars($user['fullname']); ?>!</h2>
    <p>Email: <?php echo htmlspecialchars($user['email']); ?></p>
    <p>Vai trò: <?php echo ($user['role'] === 'admin') ? 'Quản trị viên' : 'Khách hàng'; ?></p>
    
    <a href="index.php">Trang chủ</a> |
    <a href="cart.php">Giỏ hàng</a> |
    <a href="logout.php">Đăng xuất</a>
</body>
</html>

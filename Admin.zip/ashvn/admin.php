<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Quản lý Sản phẩm & Đơn hàng</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body { font-family: Arial, sans-serif; background: #f8f9fa; padding: 20px; }
        .container { max-width: 900px; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        th { background: #007bff; color: white; }
        tr:nth-child(even) { background: #f2f2f2; }
        .btn { padding: 8px 12px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:hover { background: #218838; }
    </style>
</head>
<body>

<div class="container">
    <h2>Quản lý Sản phẩm</h2>

    <!-- Form Thêm Sản Phẩm -->
    <form action="add_product.php" method="POST" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Tên sản phẩm" required>
        <input type="number" name="price" placeholder="Giá (VND)" required>
        <input type="text" name="category" placeholder="Danh mục" required>
        <input type="file" name="image" required>
        <button type="submit" class="btn">Thêm sản phẩm</button>
    </form>

    <!-- Danh sách sản phẩm -->
    <table>
        <tr>
            <th>Hình ảnh</th>
            <th>Tên sản phẩm</th>
            <th>Giá</th>
            <th>Danh mục</th>
        </tr>
        <?php
        $sql = "SELECT * FROM sanpham";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td><img src='uploads/{$row['image']}' width='50'></td>
                    <td>{$row['name']}</td>
                    <td>" . number_format($row['price'], 0, ',', '.') . " VND</td>
                    <td>{$row['category']}</td>
                  </tr>";
        }
        ?>
    </table>

    <h2>Quản lý Đơn hàng</h2>
    <table>
        <tr>
            <th>Mã đơn hàng</th>
            <th>Khách hàng</th>
            <th>Sản phẩm</th>
            <th>Số lượng</th>
            <th>Tổng tiền</th>
            <th>Thời gian</th>
        </tr>
        <?php
        $sql = "SELECT orders.id AS order_id, users.username, sanpham.name AS product_name, 
                       order_items.quantity, orders.total_price, orders.order_time
                FROM orders
                JOIN users ON orders.user_id = users.id
                JOIN order_items ON orders.id = order_items.order_id
                JOIN sanpham ON order_items.product_id = sanpham.id
                ORDER BY orders.order_time DESC";

        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>#{$row['order_id']}</td>
                    <td>{$row['username']}</td>
                    <td>{$row['product_name']}</td>
                    <td>{$row['quantity']}</td>
                    <td>" . number_format($row['total_price'], 0, ',', '.') . " VND</td>
                    <td>{$row['order_time']}</td>
                  </tr>";
        }
        ?>
    </table>

    <a href="logout.php" class="btn" style="background: #dc3545;">Đăng xuất</a>
</div>

</body>
</html>

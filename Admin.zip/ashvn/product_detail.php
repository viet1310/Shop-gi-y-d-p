<?php
session_start();
include 'db_connect.php';

if (!isset($_GET['id'])) {
    die("Sản phẩm không tồn tại.");
}

$id = $_GET['id'];
$sql = "SELECT * FROM sanpham WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();
$stmt->close();
$conn->close();

if (!$product) {
    die("Sản phẩm không tồn tại.");
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?></title>
    <link rel="stylesheet" href="css/style.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h2><?php echo htmlspecialchars($product['name']); ?></h2>
    <div class="product-detail">
        <img src='<?php echo htmlspecialchars($product['image']); ?>' alt='<?php echo htmlspecialchars($product['name']); ?>'>
        <div class="product-info">
            <p><strong>Giá:</strong> <?php echo number_format($product['price']); ?> VND</p>
            <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <button id="addToCart" data-id="<?php echo $product['id']; ?>">Thêm vào giỏ hàng</button>
            <?php } else { ?>
                <p><a href="login.php">Đăng nhập</a> để mua hàng</p>
            <?php } ?>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $("#addToCart").click(function () {
                let productId = $(this).data("id");
                $.post("cart.php", { action: "add", product_id: productId }, function (response) {
                    alert(response);
                });
            });
        });
    </script>
    
    <a href="products.php">Quay lại danh sách sản phẩm</a>
</body>
</html>
<?php
session_start();
include 'db_connect.php';

$sql = "SELECT DISTINCT category FROM sanpham";
$categories = $conn->query($sql);

$sql = "SELECT * FROM sanpham LIMIT 8";
$featured_products = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ASH.VN - Trang chủ</title>
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    <header>
        <h1>ASH.VN</h1>
        <nav>
            <a href="index.php">Trang chủ</a>
            <a href="products.php">Sản phẩm</a>
            <a href="cart.php">Giỏ hàng</a>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="user_dashboard.php">Tài khoản</a>
                <a href="logout.php">Đăng xuất</a>
            <?php } else { ?>
                <a href="login.php">Đăng nhập</a>
            <?php } ?>
        </nav>
    </header>

    <section id="categories">
        <h2>Danh mục sản phẩm</h2>
        <ul>
            <?php while ($row = $categories->fetch_assoc()) { ?>
                <li><a href='products.php?category=<?php echo urlencode($row['category']); ?>'><?php echo htmlspecialchars($row['category']); ?></a></li>
            <?php } ?>
        </ul>
    </section>

    <section id="featured-products">
        <h2>Sản phẩm nổi bật</h2>
        <div class="product-grid">
            <?php while ($row = $featured_products->fetch_assoc()) { ?>
                <div class='product-card'>
                    <img src='<?php echo htmlspecialchars($row['image']); ?>' alt='<?php echo htmlspecialchars($row['name']); ?>'>
                    <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                    <p>Giá: <?php echo number_format($row['price']); ?> VND</p>
                    <a href='product_detail.php?id=<?php echo $row['id']; ?>'>Xem chi tiết</a>
                </div>
            <?php } ?>
        </div>
    </section>

    <footer>
        <p>&copy; 2025 ASH.VN</p>
    </footer>
</body>
</html>
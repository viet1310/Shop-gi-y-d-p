<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    die("Vui lòng <a href='login.php'>đăng nhập</a> để xem giỏ hàng.");
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add' && isset($_POST['product_id'])) {
        $product_id = $_POST['product_id'];
        
        $sql = "SELECT * FROM sanpham WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();
        $stmt->close();
        
        if ($product) {
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }
            
            if (!isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id] = [
                    'name' => $product['name'],
                    'price' => $product['price'],
                    'quantity' => 1
                ];
            } else {
                $_SESSION['cart'][$product_id]['quantity']++;
            }
            echo "Đã thêm vào giỏ hàng!";
        } else {
            echo "Sản phẩm không tồn tại!";
        }
    }
    exit();
}

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giỏ hàng</title>
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    <h2>Giỏ hàng</h2>
    <?php if (!empty($_SESSION['cart'])) { ?>
        <table border="1">
            <tr>
                <th>Sản phẩm</th>
                <th>Giá</th>
                <th>Số lượng</th>
                <th>Tổng</th>
            </tr>
            <?php $total = 0; foreach ($_SESSION['cart'] as $id => $item) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo number_format($item['price']); ?> VND</td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td><?php echo number_format($item['price'] * $item['quantity']); ?> VND</td>
                </tr>
                <?php $total += $item['price'] * $item['quantity']; ?>
            <?php } ?>
            <tr>
                <td colspan="3"><strong>Tổng cộng:</strong></td>
                <td><strong><?php echo number_format($total); ?> VND</strong></td>
            </tr>
        </table>
        <a href="checkout.php">Tiến hành thanh toán</a>
    <?php } else { ?>
        <p>Giỏ hàng trống.</p>
    <?php } ?>
    <a href="products.php">Tiếp tục mua sắm</a>
</body>
</html>

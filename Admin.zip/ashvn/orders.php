<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Truy cập bị từ chối. <a href='index.php'>Về trang chủ</a>");
}

$sql = "SELECT orders.id, users.fullname, users.email, orders.address, orders.total_price, orders.created_at 
        FROM orders JOIN users ON orders.user_id = users.id ORDER BY orders.created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Đơn hàng</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Danh sách Đơn hàng</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Khách hàng</th>
            <th>Email</th>
            <th>Địa chỉ</th>
            <th>Tổng tiền</th>
            <th>Ngày đặt</th>
            <th>Chi tiết</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo htmlspecialchars($row['fullname']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td><?php echo htmlspecialchars($row['address']); ?></td>
                <td><?php echo number_format($row['total_price']); ?> VND</td>
                <td><?php echo $row['created_at']; ?></td>
                <td>
                    <a href="order_detail.php?id=<?php echo $row['id']; ?>">Xem chi tiết</a>
                </td>
            </tr>
        <?php } ?>
    </table>
    <a href="admin.php">Quay lại trang quản trị</a>
</body>
</html>

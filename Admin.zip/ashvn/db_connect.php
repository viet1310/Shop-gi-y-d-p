<?php
$servername = "127.0.0.1"; // Hoặc "localhost"
$username = "root";        // XAMPP mặc định là "root"
$password = "";            // Mặc định không có mật khẩu
$database = "ashvn";       // Đảm bảo đã tạo database này

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
?>

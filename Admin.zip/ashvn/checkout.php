<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    die("Vui lòng <a href='login.php'>đăng nhập</a> để thanh toán.");
}

if (empty($_SESSION['cart'])) {
    die("Giỏ hàng trống. <a href='products.php'>Mua sắm ngay</a>");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $address = $_POST['address'];
    $total_price = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $_SESSION['cart']));
    
    $sql = "INSERT INTO orders (user_id, address, total_price) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isd", $user_id, $address, $total_price);
    if ($stmt->execute()) {
        $order_id = $stmt->insert_id;
        foreach ($_SESSION['cart'] as $product_id => $item) {
            $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iiid", $order_id, $product_id, $item['quantity'], $item['price']);
            $stmt->execute();
        }
        unset($_SESSION['cart']);
        echo "<p>Đặt hàng thành công! <a href='index.php'>Về trang chủ</a></p>";
    } else {
        echo "<p>Lỗi khi đặt hàng!</p>";
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh toán</title>
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    <h2>Thanh toán</h2>
    <form method="POST" action="">
        <label>Địa chỉ giao hàng:</label><br>
        <input type="text" name="address" required><br>
        <p>Tổng tiền: <strong><?php echo number_format(array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $_SESSION['cart']))); ?> VND</strong></p>
        <button type="submit">Xác nhận thanh toán</button>
    </form>
    <a href="cart.php">Quay lại giỏ hàng</a>
</body>
</html>

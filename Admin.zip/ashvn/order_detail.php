<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Truy cập bị từ chối. <a href='index.php'>Về trang chủ</a>");
}

if (!isset($_GET['id'])) {
    die("Không tìm thấy đơn hàng.");
}

$order_id = $_GET['id'];

$sql = "SELECT orders.id, users.fullname, users.email, orders.address, orders.total_price, orders.created_at 
        FROM orders JOIN users ON orders.user_id = users.id WHERE orders.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_result = $stmt->get_result();
$order = $order_result->fetch_assoc();
$stmt->close();

if (!$order) {
    die("Đơn hàng không tồn tại.");
}

$sql = "SELECT order_items.product_id, sanpham.name, order_items.quantity, order_items.price 
        FROM order_items 
        JOIN sanpham ON order_items.product_id = sanpham.id 
        WHERE order_items.order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$items_result = $stmt->get_result();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết Đơn hàng</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Chi tiết Đơn hàng #<?php echo $order['id']; ?></h2>
    <p><strong>Khách hàng:</strong> <?php echo htmlspecialchars($order['fullname']); ?> (<?php echo htmlspecialchars($order['email']); ?>)</p>
    <p><strong>Địa chỉ giao hàng:</strong> <?php echo htmlspecialchars($order['address']); ?></p>
    <p><strong>Ngày đặt hàng:</strong> <?php echo $order['created_at']; ?></p>
    <p><strong>Tổng tiền:</strong> <?php echo number_format($order['total_price']); ?> VND</p>

    <h3>Sản phẩm trong đơn hàng</h3>
    <table border="1">
        <tr>
            <th>Tên sản phẩm</th>
            <th>Số lượng</th>
            <th>Giá</th>
            <th>Tổng</th>
        </tr>
        <?php while ($item = $items_result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($item['name']); ?></td>
                <td><?php echo $item['quantity']; ?></td>
                <td><?php echo number_format($item['price']); ?> VND</td>
                <td><?php echo number_format($item['quantity'] * $item['price']); ?> VND</td>
            </tr>
        <?php } ?>
    </table>

    <a href="orders.php">Quay lại danh sách đơn hàng</a>
</body>
</html>
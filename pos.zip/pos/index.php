<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Cửa Hàng Sneaker</title>
</head>
<body>
<header>
    <div class="logo">
        <h1><a href="#">Sneaker Shop</a></h1>
    </div>
    <nav>
        <ul>
            <li><a href="#">Trang chủ</a></li>
            <li><a href="billing.html">Sản phẩm</a></li>
            <li><a href="#">Giới thiệu</a></li>
            <li><a href="#">Tin tức</a></li>
            <li><a href="#">Liên hệ</a></li>
        </ul>
    </nav>
    <div class="icons">
        <a href="#" class="search-icon" aria-label="Search">🔍</a>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                let user = getCookie("user_email");
                let headerIcons = document.querySelector(".icons");
                headerIcons.innerHTML = "";

                if (user) {
                    headerIcons.innerHTML += `
                        <a href="#" class="profile-icon" title="${user}">👤</a>
                        <a href="#" class="cart-icon" aria-label="Shopping Cart">🛒</a>
                        <a href="login/logout.php" class="logout-icon">🚪 Logout</a>
                    `;
                } else {
                    headerIcons.innerHTML += `
                        <a href="login/index.php" class="login-icon">🔑 Login</a>
                    `;
                }
            });

            function getCookie(name) {
                let cookies = document.cookie.split("; ");
                for (let cookie of cookies) {
                    let [key, value] = cookie.split("=");
                    if (key === name) return decodeURIComponent(value);
                }
                return null;
            }
        </script>
    </div>
</header>

    <section class="hero">
        <div class="hero-content">
            <h2>Bước vào Thế Giới Sneaker Đẳng Cấp</h2>
            <p>Khám phá bộ sưu tập giày sneaker mới nhất với thiết kế độc đáo và phong cách.</p>
            <a href="#" class="cta-button">Mua Ngay</a>
        </div>
        <div class="hero-image">
            <img src="sneaker-image.jpg" alt="Sneaker Mới Nhất">
        </div>
    </section>
    <section class="featured-products">
        <h2>Sản Phẩm Nổi Bật</h2>
        <div class="product-grid">
            <div class="product-card">
                <img src="sneaker1.jpg" alt="Sneaker 1">
                <h3>Giày Sneaker 1</h3>
                <p class="price">1.500.000 VNĐ</p>
                <a href="#" class="cta-button">Xem Chi Tiết</a>
            </div>
            <div class="product-card">
                <img src="sneaker2.jpg" alt="Sneaker 2">
                <h3>Giày Sneaker 2</h3>
                <p class="price">1.800.000 VNĐ</p>
                <a href="#" class="cta-button">Xem Chi Tiết</a>
            </div>
            <div class="product-card">
                <img src="sneaker3.jpg" alt="Sneaker 3">
                <h3>Giày Sneaker 3</h3>
                <p class="price">2.000.000 VNĐ</p>
                <a href="#" class="cta-button">Xem Chi Tiết</a>
            </div>
            <!-- Thêm nhiều sản phẩm nếu cần -->
        </div>
    </section>
    <section class="about-us">
        <h2>Giới Thiệu Về Chúng Tôi</h2>
        <div class="about-content">
            <div class="about-text">
                <p>Chào mừng bạn đến với Sneaker Shop - nơi cung cấp những mẫu giày sneaker thời thượng và chất lượng nhất. Chúng tôi cam kết mang đến cho khách hàng những sản phẩm tốt nhất với giá cả hợp lý.</p>
                <p>Đội ngũ của chúng tôi là những người đam mê thời trang và luôn theo kịp xu hướng mới nhất. Hãy cùng khám phá bộ sưu tập của chúng tôi và tìm kiếm đôi giày hoàn hảo cho bạn!</p>
            </div>
            <div class="about-image">
                <img src="team-image.jpg" alt="Đội ngũ Sneaker Shop">
            </div>
        </div>
    </section>
    <section class="testimonials">
        <h2>Đánh Giá Từ Khách Hàng</h2>
        <div class="testimonial-grid">
            <div class="testimonial-card">
                <p>"Tôi rất hài lòng với sản phẩm và dịch vụ tại Sneaker Shop. Đôi giày tôi mua rất đẹp và chất lượng!"</p>
                <h3>- Nguyễn Văn A</h3>
            </div>
            <div class="testimonial-card">
                <p>"Sneaker Shop có nhiều mẫu mã đa dạng và phong cách. Tôi chắc chắn sẽ quay lại!"</p>
                <h3>- Trần Thị B</h3>
            </div>
            <div class="testimonial-card">
                <p>"Dịch vụ khách hàng tuyệt vời! Tôi đã nhận được sự hỗ trợ nhanh chóng khi cần." </p>
                <h3>- Lê Văn C</h3>
            </div>
            <!-- Thêm nhiều đánh giá nếu cần -->
        </div>
    </section>
    <section class="latest-news">
        <h2>Tin Tức & Xu Hướng Mới Nhất</h2>
        <div class="news-grid">
            <div class="news-card">
                <img src="news1.jpg" alt="Tin tức 1">
                <h3>Bài Viết Về Xu Hướng Sneaker Mùa Hè</h3>
                <p>Khám phá những xu hướng giày sneaker mới nhất cho mùa hè này và cách phối đồ hoàn hảo.</p>
                <a href="#" class="cta-button">Đọc Thêm</a>
            </div>
            <div class="news-card">
                <img src="news2.jpg" alt="Tin tức 2">
                <h3>Top 5 Đôi Giày Sneaker Bán Chạy Nhất Năm Nay</h3>
                <p>Danh sách những đôi giày sneaker được yêu thích nhất trong năm nay mà bạn không thể bỏ lỡ.</p>
                <a href="#" class="cta-button">Đọc Thêm</a>
            </div>
            <div class="news-card">
                <img src="news3.jpg" alt="Tin tức 3">
                <h3>Cách Bảo Quản Giày Sneaker Đúng Cách</h3>
                <p>Hướng dẫn chi tiết về cách bảo quản giày sneaker để giữ chúng luôn mới và bền đẹp.</p>
                <a href="#" class="cta-button">Đọc Thêm</a>
            </div>
            <!-- Thêm nhiều bài viết nếu cần -->
        </div>
    </section>
    <section class="newsletter">
        <h2>Đăng Ký Nhận Bản Tin</h2>
        <p>Nhận thông tin về sản phẩm mới nhất, khuyến mãi và tin tức từ Sneaker Shop.</p>
        <form class="newsletter-form">
            <input type="email" placeholder="Nhập địa chỉ email của bạn" required>
            <button type="submit">Đăng Ký</button>
        </form>
    </section>
      <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Liên Hệ</h3>
                <p>Địa chỉ: 123 Đường Sneaker, Thành phố HCM</p>
                <p>Điện thoại: 0123-456-789</p>
                <p>Email: contact@sneakershop.com</p>
            </div>
            <div class="footer-section">
                <h3>Kết Nối Với Chúng Tôi</h3>
                <a href="#">Facebook</a><br>
                <a href="#">Instagram</a><br>
                <a href="#">Twitter</a><br>
            </div>
            <div class="footer-section">
                <h3>Chính Sách</h3>
                <a href="#">Chính sách bảo mật</a><br>
                <a href="#">Điều khoản sử dụng</a><br>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; 2023 Sneaker Shop. Tất cả quyền được bảo lưu.
        </div>
    </footer>
</body>
</html>
<?php
session_start();

// Connect to database
$conn = new mysqli("localhost", "root", "", "pos");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Registration
if (isset($_POST['register'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash(trim($_POST['password']), PASSWORD_BCRYPT);

    $sql = "INSERT INTO customer (name, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }

    $stmt->bind_param("sss", $name, $email, $password);
    
    if ($stmt->execute()) {
        echo "<script>alert('Registration successful! Please login.'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Registration failed! Try again.'); window.location.href='index.php';</script>";
    }
    $stmt->close();
}

// Handle Login
if (isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $sql = "SELECT customer_id, name, password FROM customer WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_email'] = $email;
            $_SESSION['user_name'] = $row['name'];
            $_SESSION['user_id'] = $row['customer_id'];

            // Redirect to http://localhost/pos/
            header("Location: http://localhost/pos/");
            exit();
        } else {
            echo "<script>alert('Invalid password.'); window.location.href='index.php';</script>";
        }
    } else {
        echo "<script>alert('No user found with this email.'); window.location.href='index.php';</script>";
    }
    $stmt->close();
}

$conn->close();
?>

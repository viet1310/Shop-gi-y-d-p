<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Signup</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <div class="form-box">
            <div class="button-box">
                <button id="loginBtn" onclick="showLogin()">Login</button>
                <button id="signupBtn" onclick="showSignup()">Signup</button>
            </div>
            <div class="form-container" id="formContainer">
                <form id="loginForm" class="form" action="login.php" method="POST">
                    <h2>Login</h2>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit" name="login">Login</button>
                </form>
                <form id="signupForm" class="form hidden" action="login.php" method="POST">
                    <h2>Signup</h2>
                    <input type="text" name="name" placeholder="Username" required>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit" name="register">Signup</button>
                </form>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>

<?php
session_start();

// Clear all session variables
session_unset();

// Destroy the session
session_destroy();

// Clear the user cookie
setcookie("user_email", "", time() - 3600, "/"); // Expire the cookie

// Redirect to the home page
header("Location: http://localhost/pos/");
exit();
?>

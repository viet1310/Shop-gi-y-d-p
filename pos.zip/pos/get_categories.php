<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$database = "pos";

// Kết nối database
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Lỗi kết nối: " . $conn->connect_error);
}

// Lấy danh sách danh mục không trùng lặp
$sql = "SELECT DISTINCT category FROM Sanpham";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<div class="category" data-category="">Tất cả</div>';
    while ($row = $result->fetch_assoc()) {
        echo '<div class="category" data-category="' . $row['category'] . '">' . $row['category'] . '</div>';
    }
} else {
    echo "Không có danh mục.";
}

$conn->close();
?>

<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$database = "pos";

// Kết nối database
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Lỗi kết nối: " . $conn->connect_error);
}

// Kiểm tra xem có lọc theo danh mục không
$category = isset($_GET['category']) && $_GET['category'] != "" ? $_GET['category'] : null;

// Truy vấn sản phẩm
if ($category) {
    $stmt = $conn->prepare("SELECT * FROM Sanpham WHERE category = ?");
    $stmt->bind_param("s", $category);
} else {
    $stmt = $conn->prepare("SELECT * FROM Sanpham");
}
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="product-card" data-name="' . $row['name'] . '" data-price="' . $row['price'] . '">
                <img src="' . $row['image_path'] . '" alt="' . $row['name'] . '">
                <p>' . $row['name'] . '</p>
                <p>' . number_format($row['price']) . ' VND</p>
              </div>';
    }
} else {
    echo "Không có sản phẩm.";
}

$stmt->close();
$conn->close();
?>

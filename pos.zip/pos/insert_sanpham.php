<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$database = "pos";

// Kết nối database
$conn = new mysqli($servername, $username, $password, $database);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Lỗi kết nối: " . $conn->connect_error);
}

// Xử lý khi nhận dữ liệu từ form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category = $_POST['category'];
    $name = $_POST['name'];
    $price = $_POST['price'];

    // Xử lý ảnh
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image_name = time() . "_" . basename($_FILES["image"]["name"]); // Đổi tên ảnh để tránh trùng
        $image_path = "uploads/" . $image_name;
        
        // Di chuyển file vào thư mục uploads
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $image_path)) {
            // Thêm vào database
            $stmt = $conn->prepare("INSERT INTO Sanpham (category, name, price, image_path) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssds", $category, $name, $price, $image_path);

            if ($stmt->execute()) {
                echo "Sản phẩm đã được thêm thành công!";
            } else {
                echo "Lỗi: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Không thể tải ảnh lên.";
        }
    } else {
        echo "Vui lòng chọn ảnh.";
    }
}

$conn->close();
?>
